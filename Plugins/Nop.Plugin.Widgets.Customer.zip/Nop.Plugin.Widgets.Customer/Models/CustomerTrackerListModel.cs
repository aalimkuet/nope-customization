﻿ 
using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.Customer.Models
{
    /// <summary>
    /// Represents a student list model
    /// </summary>
    public partial record CustomerTrackerListModel : BasePagedListModel<CustomerTrackerModel>
    {
    }
}